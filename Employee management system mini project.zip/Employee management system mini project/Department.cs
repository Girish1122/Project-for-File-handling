﻿using System;
namespace Hardwork
{
    class Department
    {
        public int deptID, NoofProjects;
        public string deptname;
        public Department()
        {
            Console.WriteLine("Enter the department ID : ");
            deptID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the department name : ");
            deptname = Console.ReadLine();
            Console.WriteLine("Enter the number of projects :");
            NoofProjects = int.Parse(Console.ReadLine());
        }
        public string display2()
        {
            return (deptID.ToString().PadLeft(20) + " | " + deptname.PadLeft(20) + "|" + NoofProjects.ToString().PadLeft(20));
        }
    }
}
