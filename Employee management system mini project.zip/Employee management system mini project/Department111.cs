﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Project
{
    class Department111
    {
        
        public string deptname;
        public int deptID, NoofProjects;
        public Department111()
        {
            Console.WriteLine("Enter the department ID : ");
            deptID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the department name : ");
            deptname = Console.ReadLine();
            Console.WriteLine("Enter the number of projects :");
            NoofProjects = int.Parse(Console.ReadLine());
        }
        public string print2()
        {
            return (deptID.ToString().PadLeft(20) + " | " + deptname.PadLeft(20) + "|" + NoofProjects.ToString().PadLeft(20));
        }
    }
}

