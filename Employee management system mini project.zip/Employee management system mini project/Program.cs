﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, ch;
            int n1, n2, n3;

            string file1 = @"C:\Users\sai\OneDrive\Desktop\employee1.txt";
            string file2 = @"C:\Users\sai\OneDrive\Desktop\department.txt";
            string file3 = @"C:\Users\sai\OneDrive\Desktop\project.txt";
            
            do
            {
                Console.WriteLine("\n1. Insert employee record  \n2. Insert department record \n3. Insert project record  \n4. Displaying Employee file record \n5. Displaying Department file record  \n6. Displaying Project file record  \n7.Search project data by employee id  \n8. Search Projects by department name \n9.Exit  \n Please enter choice :");
                ch = int.Parse(Console.ReadLine());
                string[] lines1 = File.ReadAllLines(file1);
                string[] lines2 = File.ReadAllLines(file2);
                string[] lines3 = File.ReadAllLines(file3);
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter number of records for employee file : ");
                        n1 = int.Parse(Console.ReadLine());
                        Employee111[] ob1 = new Employee111[n1];
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(file1, true))
                            {
                                for (i = 0; i < n1; i++)
                                {
                                    ob1[i] = new Employee111();

                                    writer.Write(ob1[i].print1() + "\n");
                                }
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter number of records for department file : ");
                        n2 = int.Parse(Console.ReadLine());
                        Department111[] ob2 = new Department111[n2];
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(file2, true))
                            {
                                for (i = 0; i < n2; i++)
                                {
                                    ob2[i] = new Department111();

                                    writer.Write(ob2[i].print2() + "\n");
                                }
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter number of records for project file : ");
                        n3 = int.Parse(Console.ReadLine());
                        Project111[] ob3 = new Project111[n3];
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(file3, true))
                            {
                                for (i = 0; i < n3; i++)
                                {
                                    ob3[i] = new Project111();

                                    writer.Write(ob3[i].print3() + "\n");
                                }
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 4:
                        var info1 = new FileInfo(file1);
                        if (info1.Length == 0)
                            Console.WriteLine("Employee file does not contain any record");
                        else if (File.Exists(file1))
                        {
                            Console.WriteLine("Displaying employee file contents");
                            for (int j = 0; j < lines1.Length; j++)
                                Console.WriteLine(lines1[j].ToString());
                        }
                        else
                        {
                            Console.WriteLine("Employee file does not exists !!");
                        }
                        break;
                    case 5:
                        var info2 = new FileInfo(file2);
                        if (info2.Length == 0)
                            Console.WriteLine("Department file does not contain any record");
                        else if (File.Exists(file2))
                        {
                            Console.WriteLine("Displaying department file contents");
                            for (int j = 0; j < lines2.Length; j++)
                                Console.WriteLine(lines2[j].ToString());
                        }
                        else
                        {
                            Console.WriteLine("Department file does not exists !!");
                        }
                        break;
                    case 6:
                        var info3 = new FileInfo(file3);
                        if (info3.Length == 0)
                            Console.WriteLine("Project file does not contain any record");
                        else if (File.Exists(file3))
                        {
                            Console.WriteLine("Displaying project file contents");
                            for (int j = 0; j < lines3.Length; j++)
                                Console.WriteLine(lines3[j].ToString());
                        }
                        else
                        {
                            Console.WriteLine(" Project file does not exists !!");
                        }
                        break;

                    case 7:
                        StreamReader reader2 = new StreamReader(file3);
                        Console.WriteLine("Enter the employee ID to search : ");
                        string id1 =Console.ReadLine();
                        string line2, temp = "";
                        string mgID="";
                        while ((line2 = reader2.ReadLine()) != null)
                        {
                            if (line2.Substring(61, 3) == id1)
                            {
                                mgID = id1;
                                Console.WriteLine(mgID);
                                temp = line2;
                                break;
                            }
                           
                        }
                        reader2.Close();
                        
                        if (mgID == null)
                            Console.WriteLine("employee id is not present in project File");
                        else
                        {
                            reader2 = new StreamReader(file1);
                            int flag = 0;
                            while ((line2 = reader2.ReadLine()) != null)
                            {
                                
                                if (line2.Substring(40, 3) == mgID)
                                {
                                    
                                    Console.WriteLine("Project manager found and ID is = " + mgID + " and details are as below :");
                                    Console.WriteLine("Department ID".PadLeft(20) + " | " + "Employee ID".PadLeft(20) + " | " + "Employee Name".PadLeft(20) + " | " + "Email".PadLeft(20) + " | " + "Phone No.".PadLeft(20) + " | " + "Project ID".PadLeft(20) + " | " + "Project Name".PadLeft(20) + " | " + "Manager ID".PadLeft(20));
                                    flag = 1;
                                    Console.WriteLine(line2 + " | " + temp);
                                }
                            }
                            if (flag == 0)
                            {
                                Console.WriteLine("Employee id and manager id's are not equal or same");
                            }
                            reader2.Close();
                        }
                        break;

                    case 8:
                        StreamReader reader3 = new StreamReader(file2);
                        string deptid = null, line3,name ;
                        Console.Write("Enter the department name for displaying projects for that department :");
                        name = Console.ReadLine();
                        while ((line3 = reader3.ReadLine()) != null)
                        {
                            if (line3.Substring(35, 8) == name)
                            {
                                deptid = line3.Substring(15, 5);
                                break;
                            }
                            
                        }
                        reader3.Close();
                        if (deptid == null)
                            Console.WriteLine("Department id is not present in department file");
                        else
                        {
                             reader3 = new StreamReader(file3);
                            int flag = 0;
                            while ((line3 = reader3.ReadLine()) != null)
                            {
                                  Console.WriteLine(line3.Substring(80, 5));
                                if (line3.Substring(80, 5) == deptid)
                                {
                                    if (flag == 0)
                                    {
                                        Console.WriteLine("Projects for department : "+ name);
                                        Console.WriteLine("Project ID".PadLeft(20) + "Project Name".PadLeft(20) + "Department ID".PadLeft(20) + "Employee ID".PadLeft(20));
                                    }
                                    flag = 1;
                                    Console.WriteLine(line3);
                                }
                            }
                            if (flag == 0)
                                Console.WriteLine("Department file does not contain any project name as : "+name);
                                reader3.Close();
                        }
                         break;
                            case 9:break;
                    default:
                        Console.WriteLine("Please enter valid choice....again!");
                        break;

                }
            } while (ch != 9);

        }
    }
}
