﻿using System;
namespace Hardwork
{
    class Project
    {
        public int magID, projID, deptID;
        string projname;
        public Project()
        {
            Console.WriteLine("Enter the project ID : ");
            projID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the project name : ");
            projname = Console.ReadLine();
            Console.WriteLine("Enter the manager ID : ");
            magID = int.Parse(Console.ReadLine());
        }
        public string display3()
        {
            return (projID.ToString().PadLeft(20) + " | " + projname.PadLeft(20) + "|" + magID.ToString().PadLeft(20) );
        }
    }
}
