﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Project
{
    class Project111
    {
        string projname;
        public int magID, projID, deptID;
        public Project111()
        {
            Console.WriteLine("Enter the project ID : ");
            projID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the project name : ");
            projname = Console.ReadLine();
            Console.WriteLine("Enter the manager ID : ");
            magID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the department ID : ");
            deptID = int.Parse(Console.ReadLine());
        }
        public string print3()
        {
            return (projID.ToString().PadLeft(20) + " | " + projname.PadLeft(20) + "|" + magID.ToString().PadLeft(20)+ "|" + deptID.ToString().PadLeft(20));
        }
    }
}
