﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hardwork
{
    class FileManagement
    {
        static void Main(string[] args)
        {
            int i, ch;
            int n1, n2, n3;

            string filename1 = @"C:\Users\sai\OneDrive\Desktop\employee1.txt";
            string filename2 = @"C:\Users\sai\OneDrive\Desktop\department.txt";
            string filename3 = @"C:\Users\sai\OneDrive\Desktop\Project112.txt";
            StreamReader reader = new StreamReader(filename3);
            do
            {
                Console.WriteLine("\n1. Insert employee record  \n2. Insert department record \n3. Insert project record  \n4. Displaying Employee file record \n5. Displaying Department file record  \n6. Displaying Project file record \n7.Search project data by employee id  \n8.Exit  \n Please enter choice :");
                ch = int.Parse(Console.ReadLine());
                string[] lines1 = File.ReadAllLines(filename1);
                string[] lines2 = File.ReadAllLines(filename2);
                string[] lines3 = File.ReadAllLines(filename3);
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter number of records for employee file : ");
                        n1 = int.Parse(Console.ReadLine());
                        Employee1[] ob1 = new Employee1[n1];
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename1, true))
                            {
                                for (i = 0; i < n1; i++)
                                {
                                    ob1[i] = new Employee1();

                                    writer.Write(ob1[i].display1() + "\n");
                                }
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter number of records for department file : ");
                        n2 = int.Parse(Console.ReadLine());
                        Department[] ob2 = new Department[n2];
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename2, true))
                            {
                                for (i = 0; i < n2; i++)
                                {
                                    ob2[i] = new Department();

                                    writer.Write(ob2[i].display2() + "\n");
                                }
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter number of records for project file : ");
                        n3 = int.Parse(Console.ReadLine());
                        Project[] ob3 = new Project[n3];
                        try
                        {
                            using (StreamWriter writer = new StreamWriter(filename3, true))
                            {
                                for (i = 0; i < n3; i++)
                                {
                                    ob3[i] = new Project();

                                    writer.Write(ob3[i].display3() + "\n");
                                }
                            }
                        }
                        catch (Exception ob)
                        {
                            Console.WriteLine(ob.Message);
                        }
                        break;
                    case 4:


                        var info1 = new FileInfo(filename1);
                        if (info1.Length == 0)
                            Console.WriteLine("Employee file does not contain any record");
                        else if (File.Exists(filename1))
                        {
                            Console.WriteLine("Displaying employee file contents");
                            for (int j = 0; j < lines1.Length; j++)
                                Console.WriteLine(lines1[j].ToString());
                        }
                        else
                        {
                            Console.WriteLine("Employee file does not exists !!");
                        }
                        break;
                    case 5:
                        var info2 = new FileInfo(filename2);
                        if (info2.Length == 0)
                            Console.WriteLine("Department file does not contain any record");
                        else if (File.Exists(filename2))
                        {
                            Console.WriteLine("Displaying department file contents");
                            for (int j = 0; j < lines2.Length; j++)
                                Console.WriteLine(lines2[j].ToString());
                        }
                        else
                        {
                            Console.WriteLine("Department file does not exists !!");
                        }
                        break;
                    case 6:
                        var info3 = new FileInfo(filename3);
                        if (info3.Length == 0)
                            Console.WriteLine("Project file does not contain any record");
                        else if (File.Exists(filename3))
                        {
                            Console.WriteLine("Displaying project file contents");
                            for (int j = 0; j < lines3.Length; j++)
                                Console.WriteLine(lines3[j].ToString());
                        }
                        else
                        {
                            Console.WriteLine(" Project file does not exists !!");
                        }
                        break;
                    case 7:
                        Console.WriteLine("Enter the employee ID to search : ");
                        string id = Console.ReadLine();
                        string line, temp = "", mgID = null;
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (line.Substring(line.Length - 3) == id)
                            {
                                mgID = line.Substring(line.Length - 3);
                                temp = line;
                                break;
                            }
                        }
                        reader.Close();
                        if (mgID == null)
                            Console.WriteLine("employee id is not present in project File");
                        else
                        {
                            reader = new StreamReader(filename1);
                            int flag = 0;
                            while ((line = reader.ReadLine()) != null)
                            {
                                if (line.Substring(40, 3) == mgID)
                                {
                                    if (flag == 0)
                                    {
                                        Console.WriteLine("Project manager found and ID is = " + mgID + " and details are as below :");
                                        Console.WriteLine("Department ID".PadLeft(20) + " | " + "Employee ID".PadLeft(20) + " | " + "Employee Name".PadLeft(20) + " | " + "Email".PadLeft(20) + " | " + "Phone No.".PadLeft(20) + " | " + "Project ID".PadLeft(20) + " | " + "Project Name".PadLeft(20) + " | " + "Manager ID".PadLeft(20));
                                    }
                                    flag = 1;
                                    Console.WriteLine(line + " | " + temp);
                                }
                            }
                            if (flag == 0)
                            {
                                Console.WriteLine("Employee id and manager id's are not equal or same");
                            }
                            reader.Close();
                        }
                        break;

                    case 8:
                        break;
                    default:
                        Console.WriteLine(" Invalid choice");
                        break;

                }
            } while (ch != 8);

        }
    }
}
